#!/bin/bash

node init.js
npm run start